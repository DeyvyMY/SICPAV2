<template>
    <div class="card">
        <div class="card-header header-elements-inline">
            <h3 class="card-title">H3 title</h3>
            <div class="header-elements">
                <div class="list-icons">
                    <a class="list-icons-item" data-action="collapse"></a>
                    <a class="list-icons-item" data-action="reload"></a>
                    <a class="list-icons-item" data-action="remove"></a>
                </div>
            </div>
        </div>

        <div class="card-body">

            este es un componente vue
        </div>
    </div>
    
</template>

<script>

    export default {
        name: "item"
    }

</script>

