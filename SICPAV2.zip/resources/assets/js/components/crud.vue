<template>
    
</template>

<script>
    export default {
        name: "crud"
    }
</script>

<style scoped>

</style>